========================================================
CPUminer for GC3355 5-chip DualMiner USB ASIC OC EDITION
========================================================

This is a special OVERCLOCK EDITION of the latest version of the modified CPUminer for Gridseeds 5-chip DualMiner ASIC devices compiled for Windows. This is the version that has the built-in fix for lower power consumption when minin only in Scrypt mode, so it is recommended to use this version instead of the original provided one. With this version you should be getting only about 8W of power consumption instead of about 60W when mining only Scrypt crypto currencies!

Set your setings in the miner-START.bat file and run it to start mining with lower power consumption.

This special OC edition allows the user to set higher operating frequencies of the GC3355 chips. The normal version of cpuminer supports frequencies of up to 900 MHz (in steps of 50). The OVERCLOCK EDITION we have made allos you to go for higher operating frequency above 900 MHz - you can try running the chips at 950, 1000, 1100 and 1200 (use the --freq=xxx command line parameter to set these frequencies). We have found our test miner to perform best with 850 MHz, however yours might be able to function at higher frequency without problems (many HW errors), so you might want to try higher than 900 MHz all the way up to 1200. At 1000 MHz the device consumes about 9W and at 1200 MHz the power consumption might go as high as 10W, so there should be no problem with the cooling, however the chips might not be able to run well at so high frequencies and can give more or only HW errors!

USING HIGHER FREQUENCIES THAN 900 MHZ MAY LEAD TO DAMAGE OF YOUR ASIC DEVICE, SO DO OVERCLOCK AT HIGHER FREQUENCY AT YOUR OWN RISK!!!  
 

Modified and compiled for Windows and provided to you by http://www.cryptomining-blog.com

---

Donations are welcome:
BTC: 14vZ4DHDzhttzKyNAmLzpRq6VLmCGb16vX
LTC: Lav98DMvJbvMGFV8QFrhk6hxJWKMVg9fFR